package net.javaguides.sms.service;

import java.util.List;
//import java.util.Optional;

import net.javaguides.sms.entity.Student;

public interface StudentService {
	List<Student> getAllStudents();
	
	Student saveStudent(Student student);
	
	Student getStudentById(Long id);
	
	Student updateStudent(Student student);
	
	void deleteStudentById(Long id);
	
	Student getStudentByEmail(String email);

	
//Optional<Student> getStudentCheckById(Long Id);
	
	
	Student getStudentByPhoneNumber(Long phoneNumber);

	List<Student> getStudentsByFirstName(String name);
	List<Student> getStudentsByLastName(String name);
	
}