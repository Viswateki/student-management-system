package net.javaguides.sms.service.impl;

import java.util.List;
//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import net.javaguides.sms.entity.Student;
import net.javaguides.sms.repository.StudentRepository;
import net.javaguides.sms.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
@Autowired
	private StudentRepository studentRepository;
	

//@Override
public Student getStudentByEmail(String email) {
	return studentRepository.findStudentByEmail(email);
	
}
//@Override
public Student getStudentByPhoneNumber(Long phoneNumber){
	return studentRepository.findStudentByPhoneNumber(phoneNumber);
}
//	@Override
	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}
//	

//	@Override
	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}

//	@Override
	public Student getStudentById(Long id) {
		return studentRepository.findById(id).orElse(null);
//		if(a!=null)
//		return a;
//		else
//			return new Student();
	}

//	@Override edited by me
	public Student updateStudent(Student student) {
		return studentRepository.save(student);
	}

//	@Override 
	public void deleteStudentById(Long id) {
		studentRepository.deleteById(id);	
	}
//	public Optional<Student> getStudentCheckById(Long id) {
//		return studentRepository.findById(id);
//		
//	}
	public List<Student> getStudentsByFirstName(String name) {
		return studentRepository.findAllByFirstName(name);
	}
	public List<Student> getStudentsByLastName(String name) {
		return studentRepository.findAllByLastName(name);
	}
}