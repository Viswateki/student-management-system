package net.javaguides.sms.service;

//import java.util.Collection;
import java.util.List;

import net.javaguides.sms.entity.Mapper;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;

//import net.javaguides.sms.repository.MapperRepository;

public interface MapperService {
	List<String> getCourseById(Long id);

	Mapper saveMapper(Mapper a);

//void deleteMapperById(Long id);

	Mapper getMapperById(Long id);

	void deleteMapperById(Long id);

	void deleteCourseListById(Long id);
	
	public List<Mapper> getAllMappers();

	Mapper getMapperByName(String name);

}
