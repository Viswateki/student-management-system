package net.javaguides.sms.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import net.javaguides.sms.entity.Courses;


import org.springframework.beans.factory.annotation.*;

import net.javaguides.sms.repository.CourseRepository;

import net.javaguides.sms.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseRepository courseRepository;
	public List<Courses> getAllCourses() {
		return courseRepository.findAll();
	}
//	@Override
	public Courses saveCourse(Courses course) {
		return courseRepository.save(course);
	}

//	@Override
	public Courses getCourseById(Long id) {
		return courseRepository.findById(id).orElse(null);
	}

//	@Override edited by me
	public Courses updateCourse(Courses course) {
		return courseRepository.save(course);
	}

//	@Override
	public void deleteCourseById(Long id) {
		
		courseRepository.deleteById(id);	
	}
public Courses getCourseByName(String courseName) {
		return courseRepository.findCoursesByCourseName(courseName);
	}
//public List<String> getAllByCourseName(){
//	return courseRepository.findAllByCourseName();
//}
}


