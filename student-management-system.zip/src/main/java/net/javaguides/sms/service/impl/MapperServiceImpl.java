package net.javaguides.sms.service.impl;

import java.util.List;
//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguides.sms.repository.MapperRepository;
import net.javaguides.sms.service.MapperService;
//import net.javaguides.sms.*;
import net.javaguides.sms.entity.Mapper;
//import net.javaguides.sms.entity.Student;
@Service
public class MapperServiceImpl implements MapperService{
	@Autowired
	private MapperRepository mapperRepository;
    
	public List<String> getCourseById( Long id) {
		return mapperRepository.findCourseById(id);
		
	}
	public Mapper saveMapper(Mapper m) {
//		Mapper m=new Mapper(id,a);
		return mapperRepository.save(m);
	}
	public Mapper getMapperById(Long id) {
		return mapperRepository.findMapperById(id);
	}
	public void deleteMapperById(Long id) {
		mapperRepository.deleteById(id);
	
	}
	public void deleteCourseListById(Long id) {
		mapperRepository.deleteCourseListById(id);
	}
	public List<Mapper> getAllMappers(){
		return mapperRepository.findAll();
	}
	public Mapper getMapperByName(String name) {
		return mapperRepository.findByName(name);
	}
	
}
