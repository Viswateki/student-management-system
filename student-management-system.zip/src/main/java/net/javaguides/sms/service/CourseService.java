package net.javaguides.sms.service;
import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;

import net.javaguides.sms.entity.Courses;
//import net.javaguides.sms.repository.CourseRepository;

public interface CourseService {
//	@Autowired
//	CourseRepository courseRepository;
	List<Courses> getAllCourses();
Courses saveCourse(Courses course);
	
	Courses getCourseById(Long id);
	
	Courses updateCourse(Courses course);
	
	void deleteCourseById(Long id);
//	Courses getCourseByName(String courseName);
	 Courses getCourseByName(String courseName); 
//	{		 TODO Auto-generated method stub
//return courseRepository.findCourseByName(courseName);
//	}
//	 List<String> getAllByCourseName();
}
