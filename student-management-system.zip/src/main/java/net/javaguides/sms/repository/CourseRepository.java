package net.javaguides.sms.repository;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguides.sms.entity.Courses;

public interface CourseRepository extends JpaRepository<Courses,Long>{

	Courses findCoursesByCourseName(String courseName);
//	List<String> findAllByCourseName();
//	List<String> findAllByCourseName();



//	public Courses findCoursesByName(String courseName);

}
