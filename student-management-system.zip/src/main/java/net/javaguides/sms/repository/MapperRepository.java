package net.javaguides.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguides.sms.entity.Mapper;
//import net.javaguides.sms.service.impl.List;
import java.util.*;
public interface MapperRepository extends JpaRepository<Mapper,Long> {

public List<String> findCourseById(Long id);

//public Mapper saveMapper(Mapper m);
public Mapper findMapperById(Long id);

public void deleteCourseListById(Long id);

public Mapper findByName(String name);

}
