package net.javaguides.sms.controller;



import org.springframework.beans.factory.annotation.*;
//import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.*;
//import org.springframework.web.server.ResponseStatusException;

import net.javaguides.sms.entity.Student;
import net.javaguides.sms.service.MapperService;
//import net.javaguides.sms.service.CourseService;
import net.javaguides.sms.service.StudentService;

@Controller
public class StudentController {
	@Autowired
	private StudentService studentService;
//	@Autowired
//	private CourseService courseService;
	@Autowired
	private MapperService mapperService;


	// handler method to handle list students and return mode and view
	@GetMapping("/students")
	public String listStudents(Model model){
		model.addAttribute("students", studentService.getAllStudents());
		return "students";
	}

	@GetMapping("/students/new")
public String createStudentForm(Model model) {
		
		// create student object to hold student form data
		Student student = new Student();
		model.addAttribute("student", student);
		return "create_student";
}
	 
	@PostMapping("/students")
	public String saveStudent(@ModelAttribute("student") Student student,Model m) {
		Student StudentByEmail = studentService.getStudentByEmail(student.getEmail());
		
		if(StudentByEmail!=null) 
		{
			m.addAttribute("emailExists", true);
			return "empty";}
//				 throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Email already exists!");
//				 return null;}
		
		Student StudentByPhoneNumber = studentService.getStudentByPhoneNumber(student.getPhoneNumber());
		if(StudentByPhoneNumber!=null) {
			m.addAttribute("phoneNumberExists", true);
			return "empty";
		}

		Student StudentById = studentService.getStudentById(student.getId());
		if(StudentById!=null) {
			m.addAttribute("idExists", true);
			return "empty";
		}
		studentService.saveStudent(student);
		return "redirect:/students";
	}
	
	 @GetMapping("/students/edit/{id}")
	public String editStudentForm(@PathVariable Long id, Model model) {
		model.addAttribute("student", studentService.getStudentById(id));
		return "edit_student";
	}

	@PostMapping("/students/{id}")
	public String updateStudent(@PathVariable Long id,@ModelAttribute("student") Student student,Model model) {
		
		// get student from database by id
		Student existingStudent = studentService.getStudentById(id);
//		System.out.println(id);
		Student StudentByEmail =studentService.getStudentByEmail(student.getEmail());
//		if(Student1!=null && Student1.getId()!=student.getId()) 
//		{
//			model.addAttribute("emailExists", true);
//			return "empty";}
		Student StudentByPhoneNumber = studentService.getStudentByPhoneNumber(student.getPhoneNumber());
//		if(Student2!=null&&Student1.getId()!=student.getId()) {
//			model.addAttribute("phoneNumberExists", true);
//			return "empty";
//		}
		Student StudentById = studentService.getStudentById(id);
//	if(Student1==null && Student2==null&& Student3==null) {
		
		// save updated student object
//		}
//	else {
		if(StudentByEmail!=null && StudentByEmail.getId()!=id)
		{model.addAttribute("emailExists", true);
		return "empty";
			
		}
		 if(StudentByPhoneNumber!=null&&StudentByPhoneNumber.getId()!=id) {
			model.addAttribute("phoneNumberExists", true);
			return "empty";
		}
		 if(StudentById!=null&&StudentById.getId()!=id) {
			model.addAttribute("idExists", true);
			return "empty";
		}
//		 System.out.println(student.getFirstName()+"  "+student.getLastName()+"  "+student.getEmail()+"  "+student.getPhoneNumber());
			existingStudent.setId(id);
			existingStudent.setFirstName(student.getFirstName());
			existingStudent.setLastName(student.getLastName());
			existingStudent.setEmail(student.getEmail());
			existingStudent.setPhoneNumber(student.getPhoneNumber());
			studentService.updateStudent(existingStudent);
//	}
	
	return "redirect:/students";
	}
	
	// handler method to handle delete student request
	@GetMapping("/students/{id}")
	public String deleteStudent(@PathVariable Long id) {
		if(mapperService.getMapperById(id)!=null) 
		mapperService.deleteMapperById(id);
		studentService.deleteStudentById(id);
		
		return "redirect:/students";
		
	}
//	@GetMapping("/students/{id}/courses")
//		public String getStudentCourses(@PathVariable Long id,Model m) {
//		m.addAttribute("student", studentService.getStudentById(id));
//		m.addAttribute("courses", courseService.getAllCourses());
//               return "student_courses";              			
//		}
	
	
	
}