package net.javaguides.sms.controller;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import net.javaguides.sms.entity.Courses;
import net.javaguides.sms.entity.Mapper;
import net.javaguides.sms.entity.Student;
import net.javaguides.sms.service.CourseService;
import net.javaguides.sms.service.MapperService;
import net.javaguides.sms.service.StudentService;
import java.util.*;
@Controller
public class CourseController {
	@Autowired
	 private CourseService courseService;
	@Autowired
	 private StudentService studentService;
	@Autowired
	 private MapperService mapperService;
	@GetMapping("/courses")
	public String listCourses(Model model){
		model.addAttribute("courses", courseService.getAllCourses());
		return "courses";
	}
	@GetMapping("/courses/new")
	public String createCourses(Model m) {
		Courses course=new Courses();
		m.addAttribute("course",course);
		return "create_course";
	}
	@PostMapping("/courses/add")
	public String saveCourse(@ModelAttribute("course") Courses course,Model m) {
		Courses courseById=courseService.getCourseById(course.getCourseId());
		if(courseById!=null) {
			m.addAttribute("CourseIdAlreadyExist",true);
			return "empty";
		}
//		System.out.println();
		Courses courseByName=courseService.getCourseByName(course.getCourseName());
		if(courseByName!=null) {
			m.addAttribute("CourseNameAlreadyExist",true);
			return "empty";
		}
		courseService.saveCourse(course);
		return "redirect:/courses";
	}
	@GetMapping("/course/delete/{courseId}")
	public String deleteCourse(@PathVariable Long courseId) {
//		long courseId2 = Long.parseLong(courseId);
		
//		System.out.println("enter");
		List<Student> students=studentService.getAllStudents();
//		System.out.println(students);
		for(int i=0;i<students.size();i++) {
			Long id=students.get(i).getId();
//			System.out.println("loop");
			Mapper m=mapperService.getMapperById(id);
			if(m!=null) {
//				System.out.println("if");
				List<String> a=m.getCourseList();
				List<String> courses= a == null ? new ArrayList<>() : new ArrayList<>(a);
				String course=courseService.getCourseById(courseId).getCourseName();
				
				if(courses.contains(course)) {
					if(courses.size()==1) {
						mapperService.deleteMapperById(id);
					}
					else {
//					System.out.println("if2");
					courses.remove(course);
					m.setCourselist(courses);
					}}
			}
		}
//		System.out.println("ifdel");
		courseService.deleteCourseById(courseId);
		
		return "redirect:/courses";
		
	}
	
	@GetMapping("/student/list/{courseName}")
	public String getListStudentsByCourse(@PathVariable String courseName,Model m) {
		Map<String,List<String>>map=new HashMap<>();
		List<String> studentName=new ArrayList<>();
		List<Mapper> mapper=mapperService.getAllMappers();
		for( Mapper i : mapper) {
			List<String> courses=i.getCourseList();
			if(courses.contains(courseName))
			{Student s=studentService.getStudentById(i.getId());
				studentName.add(s.getFirstName()+" "+s.getLastName());
			}}
		map.put(courseName,studentName);
		m.addAttribute("courseList",map);
		if(studentName.isEmpty()) {
			m.addAttribute("CourseNotEnrolled", true);
			return "empty";}
		else {
		return "course_by_students";
		}
	}
	
	
}
