package net.javaguides.sms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
//import org.springframework.web.servlet.ModelAndView;

import net.javaguides.sms.entity.*;
//import net.javaguides.sms.entity.Student;
import net.javaguides.sms.service.*;
import java.util.*;
@Controller
public class MapperController {
	@Autowired
	StudentService studentservice; 
	@Autowired
	MapperService mapperService;
	@Autowired
	CourseService courseService;
	@GetMapping("/check/student/{courseId}")
    public String getCourseById(@PathVariable("courseId") Long  courseId,Model m) {
		Student student=new Student();
		m.addAttribute("student",student);
		Courses ca=courseService.getCourseById(courseId);
		m.addAttribute("course",ca);
    	 return "student_check";
     }

     @PostMapping("/students/{courseName}/save")
     public String check(@PathVariable("courseName") String courseName,@ModelAttribute Student student,Model model)
     {
//    	 System.out.println(mapper.getId());
//    	 Student student=studentservice.getStudentById(m.getId());
//    	 System.out.println(student.getId());
    	 Mapper mapper=new Mapper();
    	 List<Student> students=studentservice.getAllStudents();
//    	List<Student> sln=studentservice.getStudentsByLastName(student.getLastName());
    	 
    	for(Student i  : students) {
//    	 System.out.println(i.getFirstName()+"  "+student.getFirstName()+"  "+i.getLastName()+"  "+student.getLastName());
    		if(i.getFirstName().trim().toLowerCase().equals(student.getFirstName().trim().toLowerCase())&&i.getLastName().trim().toLowerCase().equals(student.getLastName().trim().toLowerCase()))

    	 {
//    		 System.out.println("1");
//    		 Student s=studentservice.getStudentByName(mapper.getName());
    		 String combine=i.getFirstName()+" "+i.getLastName();
//    		 System.out.println(combine);
    		 mapper.setName(combine);
        	 mapper.setId(i.getId());}}
    	if(mapper.getName()==null)
    		 {
//    		System.out.println("2");
    		model.addAttribute("NameNExists", true);
    	  		return "empty";}
    	else {
    	 
    		 Mapper existingMapper = mapperService.getMapperByName(mapper.getName());
    	 if(existingMapper!=null) {
    		 
    		 List<String> courseList = existingMapper.getCourseList();
    		 List<String> a = courseList == null ? new ArrayList<>() : new ArrayList<>(courseList);

//    		List<String> a=new ArrayList<>(existingMapper.getCourseList());
//    		System.out.println(a);
    		 if(a.contains(courseName)){
    			 model.addAttribute("alreadyEnrolled", true);
    		 		return "empty";
    			 
    	 }
    		 else {
    			 
    			 a.add(courseName);
//    			 Mapper mapper1=mapperService.getMapperById(id);
//    		    			 Mapper ma=new Mapper(mapper1,a);
//		 mapper1.addCourse(id,a);
    			 
    			 existingMapper.setCourselist(a);
//    			 System.out.println(existingMapper.getCourseList());
//    			 System.out.println("122345");
    			 mapperService.saveMapper(existingMapper);
    			 model.addAttribute("mapper",existingMapper);
    			  
    		 }
    	 }
    	 else {
    		 List<String>a=new ArrayList<>();
    		 a.add(courseName);
//    		 Mapper ma =new Mapper(mapper.getId(),a);
    		 mapper.setCourselist(a);
    		 mapperService.saveMapper(mapper);
    		 model.addAttribute("mapper",mapper);    		 
//    		 System.out.println(mapper.getCourseList());
//    		 System.out.println("6789");
    	 }
    		 
    	}
    		 return "student_courses";		
    		 
    	 
     }
     @GetMapping("/students/{id}/courses")
		public String getStudentCourses(@PathVariable Long id,Model m) {
    	 
    	 Mapper existingMapper =mapperService.getMapperById(id);
    	 
    	 if(existingMapper==null) {
    		 m.addAttribute("NotEnrolled", true);
//    		 List<String>a=new ArrayList<>();
    		 Mapper ma=new Mapper();
    		 
    		 ma.setId(id);
    		 Student s=studentservice.getStudentById(id);
    		 String combine=s.getFirstName()+" "+s.getLastName();
    		 ma.setName(combine);
    		 List<String>a=new ArrayList<>();
    		 ma.setCourselist(a);
//    		 ma.setCourselist(a);
    		mapperService.saveMapper(ma);
//    		m.addAttribute("NotEnrolled", true);
    		m.addAttribute(ma);
//		 	System.out.println("empty");	
    		return "empty";
		 		
    	 }
    	 else if(existingMapper!=null && existingMapper.getCourseList().size()==0)
    	 {
//    		 System.out.println("existing");
    		 m.addAttribute("NotEnrolled", true);
    		 m.addAttribute("mapper",existingMapper);
    		 return "empty";
    	 }
//    	 List<String> a=new ArrayList<>(existingMapper.getCourseList());
//    	 Mapper ma=new Mapper(id,a);
//		m.addAttribute("mapper", studentservice.getStudentById(id));
//		m.addAttribute("mapper", mapperService.getCourseById(id));
    	 else {
//    	 System.out.println("existing222");
    			 m.addAttribute("mapper", existingMapper);
//    			 System.out.println(a);
//    			 System.out.println("exist");
    	 }
    	 return "student_courses";              			
		}
//     @GetMapping("/students/{id}/courses")
//     public ModelAndView getStudentCourses(@PathVariable Long id) {
//         List<String> courses = mapperService.getCourseById(id);
//         Mapper mapper = new Mapper(id, courses);
//         ModelAndView mav = new ModelAndView("student_courses");
//         mav.addObject("mapper", mapper);
//         return mav;
//     }
@GetMapping("/checkCourse/{id}")
public String checkCourse(@PathVariable Long id,Model m) {
//	mapperService.deleteCourseListById(id);
//	Mapper m=mapperService.getMapperById(id);
//	List<String>a=new ArrayList<>(m.getCourseList());
	Courses c=new Courses();
//	System.out.println(id);
	c.setCourseId(id);
	m.addAttribute("course",c);
	return "course_delete";
}
@PostMapping("/delete/course/student/{id}")
//public void print() {
//	System.out.println("hello");	 
//}
public String deleteCourseListById(@PathVariable Long  id,@ModelAttribute("course") Courses course,Model m) {
//	System.out.println(course.getCourseName());
Mapper ma=mapperService.getMapperById(id);

//System.out.println(ma.getId());
//System.out.println(ma.getCourseList());
List<String>courselist=new ArrayList<>();
List<String>b=new ArrayList<>();
for (String i :ma.getCourseList())
	b.add(i.toLowerCase());
List<String>a= b==null? new ArrayList<>() : new ArrayList<>(b);
List<Courses>c=courseService.getAllCourses();
for(Courses i :c)
	courselist.add(i.getCourseName().toLowerCase());

if(!courselist.contains(course.getCourseName().toLowerCase())) {
	m.addAttribute("CourseDNExist",true);

return "empty";}
else if(!a.contains(course.getCourseName().toLowerCase())) {
m.addAttribute("NotEnrolledThisCourse",true);
//	model.addAttribute("alreadyEnrolled", true);
return "empty";}


	
else {
	a.remove(course.getCourseName().toLowerCase());
List<String> z=new ArrayList<>();
	for(int i=0;i<a.size();i++) {
		z.add(i,a.get(i).substring(0,1).toUpperCase()+a.get(i).substring(1,a.get(i).length()).toLowerCase());
	
	}
	ma.setCourselist(z);
	mapperService.saveMapper(ma);
	m.addAttribute(ma);  
	return "student_courses";
}
}
}
