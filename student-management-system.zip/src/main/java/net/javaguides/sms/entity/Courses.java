package net.javaguides.sms.entity;
//import java.util.List;

import jakarta.persistence.*;
@Entity
@Table(name = "courses")
//
public class Courses {
	@Id
	@Column(name="Course_id")
	private Long courseId;
	@Column(name="Course_name")
	private String courseName;
	public Long getCourseId() {
		return courseId;
	}
	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	
}
	
