package net.javaguides.sms.entity;

import java.util.*;
//import java.util.HashMap;
//import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;

import jakarta.persistence.*;

@Entity
@Table(name="Mapping")
//@Component
public class Mapper {
 @Id
 @Column(name="Student_id")
 private Long id;
 @Column(name="Student_name")
 private String name;
 public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Column(name="Courses_list")
 private List<String>courseList;
// @Autowired
// private Mapper mapper;
// public Mapper getMapper() {
//	return mapper;
//}
//public void setMapper(Mapper mapper) {
//	this.mapper = mapper;
//}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public List<String> getCourseList() {
	return courseList;
}
public void setCourselist(List<String> courseList) {
	this.courseList = courseList;
}
public Mapper() {
	super();
}
//private HashMap<Long,ArrayList<String>>studentCourses=new HashMap<>();
//
//public HashMap<Long,ArrayList<String>> getStudentCourses() {
//	return studentCourses;
//}
//
//public void setStudentCourses(HashMap<Long,ArrayList<String>> studentCourses) {
//	this.studentCourses = studentCourses;
//}
//public Mapper(Long id, List<String> courseList) {
//	super();
//	this.id = id;
//	this.courseList = courseList;
//}
//public Long getMapperById() {
//	// TODO Auto-generated method stub
//	return null;
//}
//public Mapper addCourse(Long id2, List<String> a) {
//	// TODO Auto-generated method stub
//	return new Mapper(id2,a);
//	
//}
//public List<String> getCourses() {
//	// TODO Auto-generated method stub
//	return ;
//}
}
